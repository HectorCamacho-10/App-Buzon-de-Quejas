package com.dzul.appbusonquejas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class registroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)
    }
}